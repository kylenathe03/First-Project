#!/bin/bash
grep -r $1" "$2 $3_Dealer_schedule | awk -F" " '{print $1,$2,$3,$4,$5,$6,$7,$8}'

